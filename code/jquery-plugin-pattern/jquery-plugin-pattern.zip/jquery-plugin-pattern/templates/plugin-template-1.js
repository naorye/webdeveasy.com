// jQuery plugin template for plugin that does not work on element
(function($) {
	$.extend($, {
		pluginName: function(param, options) {
			options = $.extend({
				// Options Defaults
			}, options);

			// Plugin content
		
			return {
				// Plugin interface object
			};
		}
	});
})(jQuery);